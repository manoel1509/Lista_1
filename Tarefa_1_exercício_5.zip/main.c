#include <stdio.h>

int main(void) {
  
float e_altura,s_peso;
int e_sexo;

printf("Escolha o sexo [feminino:0 ou maculino:1]: \n");
scanf("%i", &e_sexo);
printf ("Digite a altura em centímetros [cm]: \n");
scanf ("%f", &e_altura);

switch (e_sexo)
{
    case 0: s_peso = 62.1*(e_altura/100)-44.7;
          printf ("Peso: %1.f [Kg] \n", s_peso);
          break;
     case 1: s_peso = 72.7*(e_altura/100)-58;
          printf ("Peso: %1.f [Kg] \n", s_peso);
         break;
     default: printf ("Erro na esolha de sexo. \n");
         break;
}
return 0;
}