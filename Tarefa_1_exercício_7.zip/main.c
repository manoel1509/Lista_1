#include <stdio.h>

int main(void) {
  
   float entrada_r1, entrada_r2, entrada_r3, entrada_r4, saida_req;
  
  printf ("Entre com valor da resistência 1 em [Ω] \n");
  scanf ("%f", &entrada_r1);
  
  printf ("Entre com valor da resistência 2 em [Ω] \n");
  scanf ("%f", &entrada_r2);
  
  printf ("Entre com valor da resistência 3 em [Ω] \n");
  scanf ("%f", &entrada_r3);
  
  printf ("Entre com valor da resistência 4 em [Ω] \n");
  scanf ("%f", &entrada_r4);
  
  saida_req = entrada_r1+entrada_r2+entrada_r3+entrada_r4;
  
  printf ("O valor da resistência equivalente: %.2f [Ω]", saida_req);
  
  return 0;
}