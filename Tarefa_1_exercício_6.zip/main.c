#include <stdio.h>
#include <math.h>

int main(void) {
  
float ent_diametro,ent_comprimento,ent_temperatura,s_resistencia,s_res_material,s_area;
int ent_material;

printf("Digite o diametro do fio em [cm]: \n");
scanf("%f", &ent_diametro);
printf ("Digite o comprimento em centímetros [cm]: \n");
scanf ("%f", &ent_comprimento);
printf ("Digite a temperatura em [°C]: \n");
scanf ("%f", &ent_temperatura);
printf ("Digite o código do material desejado:\n1.Prata\n2.Cobre\n3.Ouro\n4.Alumínio\n5.Tungstênio\n");
scanf ("%i", &ent_material);

 switch (ent_material){
  
   case 1: s_res_material=1.59*pow(10,-6)*(1+0.038)*(ent_temperatura-20);
   
    s_area=3.1416*(ent_diametro* ent_diametro)/4;
    
    s_resistencia=(s_res_material* ent_comprimento/s_area)/pow(10,-6);
    
    printf ("s_resistencia: %.3f*10^-6 [Ω] \n", s_resistencia);
   break;
   
   case 2: s_res_material=1.72*pow(10,-6)*(1+0.039)*(ent_temperatura-20);
   
    s_area=3.1416*(ent_diametro* ent_diametro)/4;
    
    s_resistencia=(s_res_material* ent_comprimento/s_area)/pow(10,-6);
    
    printf ("s_resistencia: %.3f*10^-6 [Ω] \n", s_resistencia);
   break;
   
   case 3: s_res_material=2.44*pow(10,-6)*(1+0.034)*(ent_temperatura-20);
   
    s_area=3.1416*(ent_diametro* ent_diametro)/4;
    
    s_resistencia=(s_res_material* ent_comprimento/s_area)/pow(10,-6);
    
    printf ("s_resistencia: %.3f*10^-6 [Ω] \n", s_resistencia);
   break;
   
   case 4: s_res_material=2.92*pow(10,-6)*(1+0.039)*(ent_temperatura-20);
   
    s_area=3.1416*(ent_diametro* ent_diametro)/4;
    
    s_resistencia=(s_res_material* ent_comprimento/s_area)/pow(10,-6);
    
    printf ("s_resistencia: %.3f*10^-6 [Ω] \n", s_resistencia);
   break;
   
   case 5: s_res_material=5.6*pow(10,-6)*(1+0.045)*(ent_temperatura-20);
   
    s_area=3.1416*(ent_diametro* ent_diametro)/4;
    
    s_resistencia=(s_res_material* ent_comprimento/s_area)/pow(10,-6);
    
    printf ("s_resistencia: %.3f*10^-6 [Ω] \n", s_resistencia);
   break;
   
   default: printf ("Erro na esolha do material. \n");
   break;
}
return 0;
}