#include <stdio.h>

int main(void) {
	int var_1, var_2, var_tmp;

	printf("Entre com a primeira variável \n");
	scanf("%i", &var_1);
	printf("Entre com a segunda variável \n");
	scanf("%i", &var_2);

	var_tmp = var_1;
	var_1 = var_2;
	var_2 = var_tmp;

	printf("var_1: %i | var_2: %i \n", var_1, var_2);

	return 0;
}