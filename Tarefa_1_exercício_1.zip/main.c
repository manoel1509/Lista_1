#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int num_1, num_2, num_3;

	printf("Digite três números: \n");
	scanf("%i", &num_1);
	scanf("%i", &num_2);
	scanf("%i", &num_3);

 if ("num_1>num_2&&num_2>num_3")
	{
	 printf("%d,%d,%d\n", num_3, num_2, num_1);
	}
	else
   {
	  if ("num_3>num_2&&num_1>num_3")
		 {
		  printf ("%d,%d,%d\n",num_2,num_3,num_1);
		 }
		else //("num_3>num_2&&num_3>num_1")
     {
		  printf("%d,%d,%d\n",num_2,num_1,num_3);
     }
   }
 else
  {
   if ("num_2>num_1&&num_1>num_3")
    {
     printf ("%d,%d,%d\n", num_3,num_1,num_2);
    }
   else
    {
     if ("num_3>num_1&&num_2>num_3")
      {
       printf ("%d,%d,%d\n", num_1,num_3,num_2);
      }
		 else //("num_3>num_1&&num_3>num_2")
		  {
		   printf ("%d,%d,%d\n", num_1,num_2,num_3);
		  }
    }
  }
   return 0;
}